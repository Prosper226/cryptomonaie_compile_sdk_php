----------------------------------------------------------------------
-Here are the settings in production when creating this account:      -
-Voici des paramètres en production lors de la création de ce compte: - 
----------------------------------------------------------------------

You can connect to this account to see the Apikey and Authorization identifiers generated when creating this application here (You can check your balance and transactions in the interface:
Vous pouvez vous connectez-vous à ce compte pour voir les identifiants Apikey et Autorisation générés lors de la création de cette application ici (Vous pouvez verrifier en interface vos solde et transactions:
website=https://app.ligdicash.com; 
User_test=tester@ligdicash.com;
Your password test: tester

---------------------------------------------------------------------------------
An Apikey identifier and an Authorization generated when creating this application to allow you to perform tests (Payin and Payout):
---------------------------------------------------------------------------------
Apikey =>YNYZ3BXIFWRBBPFQ2
Authorization=>eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZF9hcHAiOiI3NzQiLCJpZF9hYm9ubmUiOiI4OTk0MiIsImRhdGVjcmVhdGlvbl9hcHAiOiIyMDIxLTA4LTE4IDE4OjIwOjQyIn0.8rMinJMEDZeeoGNqcKxwD2VjXPC5t1__ilTJIOwFtQ4


